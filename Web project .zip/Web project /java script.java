// JavaScript for TravelConnect App

// Firebase configuration (replace with your Firebase config)
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

// Function to handle Google sign-in
document.getElementById('google-signup').addEventListener('click', function() {
    var provider = new firebase.auth.GoogleAuthProvider();
    auth.signInWithPopup(provider)
        .then(function(result) {
            var user = result.user;
            console.log('Google user signed in:', user);
            showHomePage(); // Redirect to home page after sign-up
        })
        .catch(function(error) {
            console.error('Google sign-in error:', error);
        });
});

// Function to handle email/password signup
document.getElementById('signup-form').addEventListener('submit', function(event) {
    event.preventDefault();
    var email = document.getElementById('signup-email').value;
    var password = document.getElementById('signup-password').value;

    auth.createUserWithEmailAndPassword(email, password)
        .then(function(userCredential) {
            var user = userCredential.user;
            console.log('User signed up:', user);
            showHomePage(); // Redirect to home page after sign-up
        })
        .catch(function(error) {
            var errorCode = error.code;
            var errorMessage = error.message;
            console.error('Sign up error:', errorMessage);
        });
});

// Function to handle email/password login
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;

    auth.signInWithEmailAndPassword(email, password)
        .then(function(userCredential) {
            var user = userCredential.user;
            console.log('Email user signed in:', user);
            showHomePage(); // Redirect to home page after login
        })
        .catch(function(error) {
            var errorCode = error.code;
            var errorMessage = error.message;
            console.error('Email sign-in error:', errorMessage);
        });
});

// Function to show the home page after successful sign-up or login
function showHomePage() {
    document.getElementById('signup').classList.add('hidden');
    document.getElementById('login').classList.add('hidden');
    document.getElementById('home').classList.remove('hidden');
}